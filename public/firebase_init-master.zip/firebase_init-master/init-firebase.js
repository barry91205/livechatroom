// TODO: Replace the following with your app's Firebase project configuration

var firebaseConfig = {
    apiKey: "<insert your API Key>",
    authDomain: "<project id>.firebaseapp.com",
    databaseURL: "https://<project id>-default-rtdb.firebaseio.com/",
    projectId: "<project id>",
    storageBucket: "gs://<project id>.appspot.com/",
};
  
// Initialize Firebase
firebase.initializeApp(firebaseConfig);